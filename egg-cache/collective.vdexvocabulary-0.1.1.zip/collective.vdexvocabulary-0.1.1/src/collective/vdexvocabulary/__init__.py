
from zope.i18nmessageid import MessageFactory
MessageFactory = MessageFactory('collective.vdexvocabulary')

